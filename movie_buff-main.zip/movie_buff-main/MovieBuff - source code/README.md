Uses relation database and SQL code to get information on Film, film reviews, groups, and users.
